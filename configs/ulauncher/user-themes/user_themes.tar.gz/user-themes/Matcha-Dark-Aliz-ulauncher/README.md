# Matcha Dark Aliz Ulauncher

A theme for Ulauncher. Matcha Dark Aliz. Based on [Matcha Dark Sea ulauncher](https://github.com/athamour1/Matcha-Dark-Sea-ulauncher) theme. 

## Screenshot
![](screenshot.png?raw=true)

## Installation

```sh
mkdir -p ~/.config/ulauncher/user-themes
git clone https://github.com/DaveHigs/Matcha-Dark-Aliz-ulauncher.git \
  ~/.config/ulauncher/user-themes/Matcha-Dark-Aliz-ulauncher
```
